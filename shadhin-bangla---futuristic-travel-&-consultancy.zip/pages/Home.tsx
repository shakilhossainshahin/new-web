
import React from 'react';
import { Link } from 'react-router-dom';
import { DESTINATIONS, SERVICES } from '../constants';

const Home: React.FC = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/id/10/1920/1080" 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950"></div>
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-4xl">
          <h1 className="text-5xl md:text-8xl font-futuristic font-bold mb-6 tracking-tight leading-none">
            UNFOLD THE <span className="text-cyan-400 neon-text">WORLD</span>
          </h1>
          <p className="text-lg md:text-2xl text-gray-300 mb-10 font-light tracking-widest uppercase">
            Travel Agency & Elite Consultancy
          </p>
          <div className="flex flex-col md:flex-row items-center justify-center gap-6">
            <Link 
              to="/destinations" 
              className="glow-button bg-cyan-500 text-black font-bold px-10 py-4 rounded-lg font-futuristic text-lg w-full md:w-auto text-center"
            >
              EXPLORE DESTINATIONS
            </Link>
            <Link 
              to="/ai-consultant" 
              className="glow-button border border-cyan-400 text-cyan-400 font-bold px-10 py-4 rounded-lg font-futuristic text-lg hover:bg-cyan-400/10 w-full md:w-auto text-center"
            >
              AI ADVISOR
            </Link>
          </div>
        </div>
        
        <div className="scanline"></div>
      </section>

      {/* Highlights Section */}
      <section className="py-24 px-4 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-6">
          <div>
            <h2 className="text-4xl font-futuristic font-bold mb-2">PREMIUM SERVICES</h2>
            <div className="h-1 w-24 bg-cyan-400"></div>
          </div>
          <p className="text-gray-400 max-w-md">
            Providing next-generation solutions for modern travelers and ambitious consultants.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {SERVICES.map((service) => (
            <div key={service.id} className="glass p-8 rounded-2xl border-l-4 border-cyan-400 hover:transform hover:-translate-y-2 transition-all duration-300 group">
              <i className={`fas ${service.icon} text-4xl text-cyan-400 mb-6 group-hover:scale-110 transition-transform`}></i>
              <h3 className="text-xl font-futuristic font-bold mb-4">{service.title}</h3>
              <p className="text-gray-400 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Destinations */}
      <section className="py-24 bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-futuristic font-bold mb-4">POPULAR HUBS</h2>
            <p className="text-gray-400">Most sought-after destinations this season</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {DESTINATIONS.map((dest) => (
              <div key={dest.id} className="relative group overflow-hidden rounded-2xl aspect-[4/5]">
                <img 
                  src={dest.image} 
                  alt={dest.name} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent flex flex-col justify-end p-8">
                  <div className="mb-2">
                    {dest.tags.map(tag => (
                      <span key={tag} className="text-[10px] bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 px-2 py-1 rounded mr-2 font-futuristic">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <h3 className="text-2xl font-futuristic font-bold mb-1">{dest.name}</h3>
                  <p className="text-gray-300 text-sm mb-4">{dest.country}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-cyan-400 font-bold text-xl">{dest.price}</span>
                    <button className="glow-button bg-white text-black text-xs font-bold px-4 py-2 rounded-full font-futuristic">
                      BOOK NOW
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
