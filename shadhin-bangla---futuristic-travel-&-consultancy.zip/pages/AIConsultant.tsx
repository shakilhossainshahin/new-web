
import React, { useState, useRef, useEffect } from 'react';
import { getTravelAdvise } from '../geminiService';
import { ChatMessage } from '../types';

const AIConsultant: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'assistant', content: 'Greetings. I am SHADHIN AI, your futuristic travel and consultancy advisor. How may I assist your global journey today?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    const response = await getTravelAdvise(input);
    const aiMsg: ChatMessage = { role: 'assistant', content: response };
    setMessages(prev => [...prev, aiMsg]);
    setIsLoading(false);
  };

  return (
    <div className="pt-20 min-h-screen bg-slate-950 flex flex-col items-center p-4 md:p-8">
      <div className="max-w-4xl w-full flex flex-col h-[80vh] glass rounded-3xl overflow-hidden shadow-2xl shadow-cyan-500/10">
        {/* Header */}
        <div className="p-6 border-b border-cyan-500/20 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-full bg-cyan-500 flex items-center justify-center animate-pulse shadow-[0_0_15px_rgba(34,211,238,0.6)]">
              <i className="fas fa-robot text-black text-xl"></i>
            </div>
            <div>
              <h2 className="font-futuristic font-bold text-xl text-cyan-400">SHADHIN AI</h2>
              <p className="text-xs text-green-400 flex items-center">
                <span className="w-2 h-2 rounded-full bg-green-400 mr-2 animate-pulse"></span>
                SYSTEM ONLINE
              </p>
            </div>
          </div>
          <div className="hidden md:block">
            <span className="text-gray-500 font-mono text-[10px]">VER: 3.0.1-PREVIEW</span>
          </div>
        </div>

        {/* Chat Area */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] md:max-w-[70%] p-4 rounded-2xl ${
                msg.role === 'user' 
                ? 'bg-cyan-500 text-black font-semibold rounded-tr-none' 
                : 'bg-slate-800/80 border border-slate-700 text-gray-200 rounded-tl-none'
              }`}>
                <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-slate-800/80 border border-slate-700 p-4 rounded-2xl rounded-tl-none flex space-x-2">
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce delay-100"></div>
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce delay-200"></div>
              </div>
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="p-6 border-t border-cyan-500/20">
          <form onSubmit={handleSubmit} className="flex space-x-4">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Query the AI advisor..."
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-6 py-4 focus:outline-none focus:border-cyan-400 transition-colors text-gray-200"
            />
            <button
              type="submit"
              disabled={isLoading}
              className="glow-button bg-cyan-500 text-black px-8 py-4 rounded-xl font-futuristic font-bold disabled:opacity-50"
            >
              SEND
            </button>
          </form>
          <p className="mt-4 text-center text-gray-600 text-[10px] tracking-widest uppercase">
            Powered by Gemini Neural Network Technology
          </p>
        </div>
      </div>
    </div>
  );
};

export default AIConsultant;
